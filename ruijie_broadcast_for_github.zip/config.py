RUIJIE_API_KEY = 'isi_api_key_ruijie_anda'
RUIJIE_API_URL = 'https://open.ruijienetworks.com/eg/authenticate'
WABLAS_API_URL = 'https://kirim.pesan/wablas/send-message'
WABLAS_TOKEN = 'isi_token_wablas_anda'