# Ruijie Cloud Broadcast Server

Sistem ini memungkinkan Anda melakukan broadcast otomatis ke pengguna yang terhubung pada jaringan WiFi menggunakan perangkat Ruijie melalui API Ruijie Cloud dan WhatsApp API (Wablas/Ultramsg).

## 🚀 Fitur

- Ambil daftar pengguna aktif dari API Ruijie Cloud
- Kirim pesan otomatis ke pengguna via WhatsApp
- Landing page untuk redirect captive portal
- Otomatisasi broadcast via cronjob
- Siap untuk dijalankan di VPS dan jaringan lokal

## 📦 Struktur

```
ruijie_broadcast/
├── app.py
├── config.py
├── ruijie_api.py
├── templates/
│   └── landing.html
└── README.md
```

## ⚙️ Instalasi

### 1. Persiapan VPS

```bash
sudo apt update && sudo apt install nginx git python3-pip -y
git clone https://github.com/USERNAME/ruijie_broadcast.git
cd ruijie_broadcast
pip3 install flask requests gunicorn
```

### 2. Konfigurasi

Edit `config.py`:
```python
RUIJIE_API_KEY = 'isi_api_key_anda'
WABLAS_TOKEN  = 'isi_token_wablas'
```

### 3. Menjalankan Server

```bash
gunicorn --bind 0.0.0.0:8080 app:app
```

Akses dari browser: `http://your-server-ip:8080`

### 4. Cron Otomatis

```bash
crontab -e
*/10 * * * * curl http://localhost:8080/
```

### 5. Captive Portal

Arahkan captive portal ke:
```
https://your-domain.com/landing?mac={client_mac}&ip={client_ip}
```

## 💬 Kontak

Dikembangkan oleh PT. Bali Eka Mediatama
Untuk integrasi ERP, dashboard admin, atau landing page dinamis, silakan hubungi kami.