from flask import Flask, render_template
from ruijie_api import get_connected_users
from config import WABLAS_API_URL, WABLAS_TOKEN
import requests

app = Flask(__name__)

def send_whatsapp(phone, message):
    headers = {
        'Authorization': WABLAS_TOKEN,
        'Content-Type': 'application/json'
    }
    data = {
        'phone': phone,
        'message': message
    }
    requests.post(WABLAS_API_URL, json=data, headers=headers)

@app.route('/')
def broadcast():
    users = get_connected_users()
    for user in users:
        phone = user.get('phone')
        if phone:
            send_whatsapp(phone, "Selamat datang di WiFi Kami! Kunjungi link ini: https://portal.bisnisanda.com/promo")
    return "Broadcast dikirim ke semua user!"

@app.route('/landing')
def landing():
    return render_template('landing.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)