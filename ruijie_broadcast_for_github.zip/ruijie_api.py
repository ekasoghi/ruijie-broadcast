import requests
from config import RUIJIE_API_KEY, RUIJIE_API_URL

def get_connected_users():
    headers = {
        'Authorization': f'Bearer {RUIJIE_API_KEY}',
        'Content-Type': 'application/json'
    }
    response = requests.get(f"{RUIJIE_API_URL}/wifi/clients", headers=headers)
    if response.status_code == 200:
        data = response.json()
        return data.get('clients', [])
    else:
        return []